package com.c1games.terminal.algo.units;

import com.c1games.terminal.algo.Config;

public enum UnitType {
    Filter,
    Encryptor,
    Destructor,
    Ping,
    EMP,
    Scrambler,
    Remove,
    Upgrade;
}
